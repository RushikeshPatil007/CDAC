package MetTours;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		/*
		 * EconomyTours obj=new EconomyTours(); System.out.println("For EconomyTours");
		 * System.out.println(obj.getDaysRent(2, 3)); PremiumTours obj1=new
		 * PremiumTours(); System.out.println("For Common:");
		 * System.out.println(obj1.getDaysForCommon(3, 4));
		 * System.out.println("For Seniors:");
		 * System.out.println(obj1.getDaysForSeniors(3, 4));
		 * System.out.println("For Woman:"); System.out.println(obj1.getDaysForWoman(3,
		 * 4));
		 */

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter no of days:");
		int days = scanner.nextInt();

		System.out.println("Enter no of Persons:");
		int noPersons = scanner.nextInt();

		EconomyTours obj = new EconomyTours();
		PremiumTours obj1 = new PremiumTours();
		System.out.println("For EconomyTours");
		System.out.println(obj.getDaysRent(days, noPersons));

		System.out.println("For Common:");
		System.out.println(obj1.getDaysForCommon(days, noPersons));
		System.out.println("For Seniors:");
		System.out.println(obj1.getDaysForSeniors(days, noPersons));
		System.out.println("For Woman:");
		System.out.println(obj1.getDaysForWoman(days, noPersons));

	}
}
