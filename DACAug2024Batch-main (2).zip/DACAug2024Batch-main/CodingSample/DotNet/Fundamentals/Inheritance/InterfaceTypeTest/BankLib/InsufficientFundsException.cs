namespace Banking;

public class InsufficientFundsException : ApplicationException {}
